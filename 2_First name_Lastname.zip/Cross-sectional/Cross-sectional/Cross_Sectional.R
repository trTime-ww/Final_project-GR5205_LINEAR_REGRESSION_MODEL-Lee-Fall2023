#set working directory
current_directory <- getwd()
setwd(current_directory)

# Load necessary libraries
library(readr)
library(lmtest)
library(ggplot2)
library(car)
library(glmnet)
library(tseries)
library(caTools)
library(caret)
library(skedastic)

# Load the dataset
data <- read_csv("Cleaned_df_without_school.csv")

# Prepare data for regression
y <- data$`Life Expectancy`
X <- subset(data, select = -c(`Life Expectancy`, Country))

# OLS regression
model <- lm(y ~ ., data = as.data.frame(X))

# Print OLS Model Summary
summary(model)

# Residual Plot
residuals <- resid(model)
predictions <- predict(model)

ggplot() +
  geom_point(aes(x = predictions, y = residuals)) +
  geom_hline(yintercept = 0, color = "red", linetype = "dashed") +
  xlab("Fitted Value") + ylab("Residuals") +
  ggtitle("Residual Plot")

# QQ Plot
qqPlot(model, main = "QQ Plot")

# MSE and RMSE
mse <- mean(residuals^2)
rmse <- sqrt(mse)
print(paste("RMSE:", rmse))
# Jarque-Bera Test (Normality)
jb_test <- jarque.bera.test(residuals)
print(jb_test)
# Breusch-Pagan Test (Homoscedasticity)
bp_test <- bptest(model)
print(bp_test)

# Durbin-Watson Test (autocorrelation)
dw_test <- dwtest(model)
print(dw_test)
# VIF
vif_data <- vif(model)
print(vif_data)

# WLS Regression
squared_residuals <- residuals^2
wls_model <- lm(y ~ ., weights = 1/squared_residuals, data = as.data.frame(X))
summary(wls_model)

# Repeating tests for WLS model
residuals_wls <- resid(wls_model)
predictions_wls <- predict(wls_model)
# MSE and RMSE
mse_wls <- mean(residuals_wls^2)
rmse_wls <- sqrt(mse)
print(paste("RMSE:", rmse))
# Jarque-Bera Test (Normality)
jb_test_wls <- jarque.bera.test(residuals_wls)
print(jb_test_wls)
# Breusch-Pagan Test (Homoscedasticity)
bp_test <- breusch_pagan(wls_model)
print(bp_test)

# Durbin-Watson Test (autocorrelation)
dw_test_wls <- sum(diff(residuals_wls)^2) / sum(residuals_wls^2)
print(dw_test_wls)


train_data <- read.csv('train_data.csv')
test_data <- read.csv('test_data.csv')

# Split the data into training and testing sets
X_train <- subset(train_data, select = -`Life.Expectancy`)
y_train <- train_data$`Life.Expectancy`
X_train <- as.matrix(X_train)
X_test <- subset(test_data, select = -`Life.Expectancy`)
X_test <- as.matrix(X_test)
y_test <- test_data$`Life.Expectancy`

X_train_with_constant <- cbind(Intercept = 1, X_train)

# Perform Lasso regression
lasso_model <- cv.glmnet(X_train, y_train, alpha = 1,nfolds = 5)
optimal_lambda <- lasso_model$lambda.min

# Predict on the test set
predictions <- predict(lasso_model, newx = X_test, s = optimal_lambda)

# Calculate Mean Squared Error
mse <- mean((predictions - y_test) ^ 2)

mean_y_test <- mean(y_test)
TSS <- sum((y_test - mean_y_test) ^ 2)

# Calculate Residual Sum of Squares (RSS)
RSS <- sum((y_test - predictions) ^ 2)

# Calculate R-squared
R_squared <- 1 - (RSS / TSS)

# Print the R-squared value
print(paste("R-squared: ", R_squared))

# Print the results
print(paste("Optimal Lambda:", optimal_lambda))
lasso_coefficients <- coef(lasso_model, s = optimal_lambda)
print("Lasso Coefficients at Optimal Lambda:")
print(lasso_coefficients)


# Calculate residuals
residuals_lasso <- y_train - predict(lasso_model, newx = X_train, s = optimal_lambda)

# Durbin-Watson Test for autocorrelation
dw_test_lasso <- dwtest(y_train ~ residuals_lasso)
print(dw_test_lasso)

# Jarque-Bera Test for normality of residuals
jb_test_lasso <- jarque.bera.test(residuals_lasso)
print(jb_test_lasso)

# Breusch-Pagan Test for homoscedasticity
resid <- residuals_lasso
exog_het <- X_train_with_constant
y <- resid^2

# Perform OLS regression of squared residuals on explanatory variables
model <- lm(y ~ exog_het)

# Extract the necessary statistics
nobs <- nrow(exog_het)
nvars <- ncol(exog_het)
fval <- summary(model)$fstatistic[1]
fpval <- pf(fval, nvars - 1, nobs - nvars, lower.tail = FALSE)
lm_statistic <- nobs * summary(model)$r.squared

# Return the Breusch-Pagan test statistic and p-value
bp_lm <- lm_statistic
bp_pval <- pchisq(bp_lm, df = nvars - 1, lower.tail = FALSE)

list(bp_lm = bp_lm, bp_pval = bp_pval, fval = fval, fpval = fpval)



# Ridge Regression
ridge_model <- cv.glmnet(X_train, y_train, alpha = 0, lambda = c(1,0.3,0.1,0.01,0.001),nfolds = 5)
optimal_lambda_ridge <- ridge_model$lambda.min

# Predict on the test set
predictions_ridge <- predict(ridge_model, newx = X_test, s = optimal_lambda_ridge)

# Calculate R-squared for Ridge
R_squared_ridge <- 1 - sum((y_test - predictions_ridge) ^ 2) / sum((y_test - mean(y_test)) ^ 2)

# Print the results for Ridge
print(paste("Ridge R-squared: ", R_squared_ridge))
print(paste("Optimal Lambda for Ridge:", optimal_lambda_ridge))
ridge_coefficients <- coef(ridge_model, s = optimal_lambda_ridge)
print("Ridge Coefficients at Optimal Lambda:")
print(ridge_coefficients)


residuals_ridge <- y_train - predict(ridge_model, newx = X_train, s = optimal_lambda_ridge)

# Durbin-Watson Test for autocorrelation
dw_test_ridge <- dwtest(y_train ~ residuals_ridge)
print(dw_test_ridge)

# Jarque-Bera Test for normality of residuals
jb_test_ridge <- jarque.bera.test(residuals_ridge)
print(jb_test_ridge)

# Breusch-Pagan Test for homoscedasticity

resid <- residuals_ridge
exog_het <- X_train_with_constant
y <- resid^2

# Perform OLS regression of squared residuals on explanatory variables
model <- lm(y ~ exog_het)

# Extract the necessary statistics
nobs <- nrow(exog_het)
nvars <- ncol(exog_het)
fval <- summary(model)$fstatistic[1]
fpval <- pf(fval, nvars - 1, nobs - nvars, lower.tail = FALSE)
lm_statistic <- nobs * summary(model)$r.squared

# Return the Breusch-Pagan test statistic and p-value
bp_lm <- lm_statistic
bp_pval <- pchisq(bp_lm, df = nvars - 1, lower.tail = FALSE)

list(bp_lm = bp_lm, bp_pval = bp_pval, fval = fval, fpval = fpval)


# Elastic Net Regression

alpha_values <- seq(0, 1, by = 0.1)

# Initialize variables to store the best model's results
best_lambda <- NULL
best_alpha <- NULL
min_test_mse <- Inf
best_model <- NULL

# Loop over alpha values to perform cross-validation
for (alpha_val in alpha_values) {
  set.seed(123) # For reproducibility
  cv_model <- cv.glmnet(X_train, y_train, alpha = alpha_val, nfolds = 5)
  
  # Get the lambda value that corresponds to the minimum MSE in cross-validation
  lambda_min_cv <- cv_model$lambda.min
  
  # Predict on the test set using the lambda from cross-validation
  predictions_test <- predict(cv_model, newx = X_test, s = lambda_min_cv)
  
  # Calculate MSE on the test set
  mse_test <- mean((y_test - predictions_test) ^ 2)
  
  # Update the best model if this model has a lower MSE on the test set
  if (mse_test < min_test_mse) {
    min_test_mse <- mse_test
    best_lambda <- lambda_min_cv
    best_alpha <- alpha_val
    best_model <- cv_model
  }
}

# Output the best alpha and lambda
cat("Optimal alpha:", best_alpha, "\n")
cat("Optimal lambda:", best_lambda, "\n")

# Coefficients of the best model
cat("Coefficients of the best model at Optimal Lambda:\n")
print(coef(best_model, s = best_lambda))

# Predictions and performance metrics for the best Elastic Net model
y_pred_test <- predict(best_model, newx = X_test, s = best_lambda)

# Calculate R-squared and Mean Squared Error on the test set
R_squared_test <- cor(y_test, y_pred_test)^2
mse_test <- mean((y_test - y_pred_test)^2)

residuals_Elastic <- y_train - predict(best_model, newx = X_train, s = best_lambda)

cat("Test R-squared:", R_squared_test, "\n")
cat("Test Mean Squared Error:", mse_test, "\n")



# Durbin-Watson Test for autocorrelation
dw_test_ridge <- dwtest(y_train ~ residuals_Elastic)
print(dw_test_ridge)

# Jarque-Bera Test for normality of residuals
jb_test_ridge <- jarque.bera.test(residuals_Elastic)
print(jb_test_ridge)

# Breusch-Pagan Test for homoscedasticity

resid <- residuals_Elastic
exog_het <- X_train_with_constant
y <- resid^2

# Perform OLS regression of squared residuals on explanatory variables
model <- lm(y ~ exog_het)

# Extract the necessary statistics
nobs <- nrow(exog_het)
nvars <- ncol(exog_het)
fval <- summary(model)$fstatistic[1]
fpval <- pf(fval, nvars - 1, nobs - nvars, lower.tail = FALSE)
lm_statistic <- nobs * summary(model)$r.squared

# Return the Breusch-Pagan test statistic and p-value
bp_lm <- lm_statistic
bp_pval <- pchisq(bp_lm, df = nvars - 1, lower.tail = FALSE)

list(bp_lm = bp_lm, bp_pval = bp_pval, fval = fval, fpval = fpval)
