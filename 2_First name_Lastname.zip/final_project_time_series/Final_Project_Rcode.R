#install.packages('readr')
#install.packages('rstudioapi')
library(readr)
library(rstudioapi)
library(ggplot2)
#set relative path
if (rstudioapi::isAvailable()) {
  file_path <- rstudioapi::getActiveDocumentContext()$path
  dir_path <- dirname(file_path)  # Extract the directory from the file path
  print(paste("Directory path:", dir_path))
  setwd(dir_path)  # Set the working directory to the directory containing the file
} else {
  print("RStudio API is not available.")
}
#import dataset
current_path = getwd()
df=read.csv('final_dataset.csv')
df=subset(df,select = -X)

# Convert 'Index' to Date and set as index (if necessary)
#df$Index <- as.Date(df$Index,format = '%Y-%m')

# Prepare plots for each column
library(gridExtra)
plot_list <- list()
for (i in names(df)[-1]) {  # Skipping the first column assuming it's 'Index'
  p <- ggplot(data = df, aes_string(x = 'Index', y = i)) +
    geom_line() +
    geom_point() +
    ggtitle(i) +
    theme_minimal()
  plot_list[[i]] <- p
}

# Arrange the plots in a 4x2 layout
do.call(grid.arrange, c(plot_list, ncol = 2, nrow = 4))
ggsave('summary.png', plot = do.call(gridExtra::grid.arrange, c(plot_list, ncol = 2, nrow = 4)))

# Assuming df is already loaded and contains the required columns

# Summary for columns 'Sea_level' to 'Stratification'
cols_group_1 <- c('Sea_level', 'Sea_CO2', 'Sea_Temperature', 'Stratification','OCH.700', 'OCH.2000', 'Ice_index', 'Salinity')
summary_df1 <- sapply(df[, cols_group_1], function(x) {
  c(max = max(x, na.rm = TRUE), min = min(x, na.rm = TRUE), mean = mean(x, na.rm = TRUE), sem = sd(x, na.rm = TRUE) / sqrt(length(na.omit(x))))
})

# Convert the summary matrix to a dataframe for pretty printing
summary_df1 <- as.data.frame(summary_df1)

# Print the summaries
#print(summary_df1)

#Drop index in df
df <- subset(df,select = -Index)

# If you have not installed the 'lmtest' package in R, run the line below:
# install.packages("lmtest")

library(lmtest)
library(zoo)
X <- subset(df, select = -Sea_level) 
y <- df$Sea_level

##### Build an initial OLS model(There is no diagnostic test value in OLS in R code )
ols_model <- lm(y ~ ., data = X) 
summary(ols_model) 

#####Draw cor_matrix plot
library(corrplot)
library(carData)
library(car)
# Assuming 'X_final' is your final dataframe after dropping 'const'
corr_matrix <- cor(X)
round(corr_matrix,2)
data_cor<-as.matrix(corr_matrix)
dev.new()
corrplot(data_cor, method = "color", type = "upper", tl.cex = 0.6, tl.col = rgb(0, 0, 0), cl.cex = 0.7,  number.cex = 0.7, col = colorRampPalette(c("blue", "white", "red"))(200), addCoef.col = "black")



#####Draw QQ plot to test the normality
res <- residuals(ols_model)

#Creating a Q-Q plot
dev.new()
#create Q-Q plot for residuals
qqnorm(res)
#add a straight diagonal line to the plot
qqline(res) 



#####Doing WLS with all 7 independent variables, weights is the 1/residuals^2
# Fit an OLS model to get residuals
ols_model <- lm(y ~ ., data = X) # The dot means 'use all other variables in the dataframe as predictors'
residuals <- residuals(ols_model)
# Create weights based on the variance of residuals
weights <- 1 / (residuals^2 + 1e-5)
# Fit the WLS model
wls_model <- lm(y ~ ., weights = weights, data = X)
# Show the results
summary(wls_model)


####Since there is multicollinearity problem, Doing VIFS to omit independent variables
# Calculate VIF for each explanatory variable
vif_data <- data.frame(feature = names(X))
vif_data$VIF <- vif(lm(as.formula(paste("Sea_level ~ ", paste(names(X), collapse = " + "))), data = df))

print(vif_data)

# Dropping 'OCH-700' and recalculating VIFs
X_reduced <- X[, !names(X) %in% "OCH.700"]
vif_data_reduced <- data.frame(feature = names(X_reduced))
vif_data_reduced$VIF <- vif(lm(as.formula(paste("Sea_level ~ ", paste(names(X_reduced), collapse = " + "))), data = df))

print(vif_data_reduced)

# Removing 'Sea_Temperature' next and recalculating VIFs
X_reduced <- X_reduced[, !names(X_reduced) %in% "Sea_Temperature"]
vif_data_reduced <- data.frame(feature = names(X_reduced))
vif_data_reduced$VIF <- vif(lm(as.formula(paste("Sea_level ~ ", paste(names(X_reduced), collapse = " + "))), data = df))

print(vif_data_reduced)


##### Now that we have selected the independent variables with reduced multicollinearity,
# we can perform OLS regression again with the reduced set of variables.
# Removing 'Sea_Temperature' and 'OCH-700' from the original X variable set
X_final <- X[, !names(X) %in% c("Sea_Temperature", "OCH.700")]

# Perform OLS regression with the reduced set of variables
ols_model_final <- lm(y ~ ., data = X_final)

# Get a summary of the final OLS model
ols_results_final_summary <- summary(ols_model_final)
print(ols_results_final_summary)


##### Draw qqplot again to test the normality of residuals
res <- residuals(ols_results_final_summary)

#Creating a Q-Q plot
dev.new()
#create Q-Q plot for residuals
qqnorm(res)
#add a straight diagonal line to the plot
qqline(res) 



library(tseries)
library(lmtest)
##### Performing the Jarque-Bera test on the residuals
jarque_bera_test <- jarque.bera.test(res)

# Jarque-Bera test results: test statistic and p-value
jb_value <- jarque_bera_test$statistic
jb_p_value <- jarque_bera_test$p.value

cat("Jarque-Bera Test Statistic:", jb_value, "\n")
cat("P-value:", jb_p_value, "\n")


##### Performing the Durbin-Watson test
dw_statistic <- dwtest(ols_model_final)
cat("Durbin-Watson statistic:", dw_statistic$statistic, "\n")


##### Performing the Breusch-Pagan test
bp_statistic <- bptest(ols_model_final)
cat("Breusch-Pagan statistic:", bp_statistic$statistic, "\n")

##### Doing GLS to fix the autocorrelation proble, the omega is a Toeplitz matrix
library(nlme)
library(lmtest)
library(tseries)

# Assuming 'residuals' are from your final OLS model 'ols_results_final'
# residuals <- residuals(ols_model_final)

# Estimate the first-order autocorrelation coefficient
acf_coefficient <- acf(res, lag.max = 1, plot = FALSE)$acf[2]

# Number of observations
n <- length(res)

# Constructing a Toeplitz matrix
toeplitz_vector <- acf_coefficient ^ seq(0, n-1)
toeplitz_matrix <- toeplitz(toeplitz_vector)
toeplitz_solve <- solve(toeplitz_matrix)
#since there is similar gls function in R as python, we transform the data and do OLS
#they actually function the same theoritically
C = chol(toeplitz_solve)
Y_star = C %*% y
C_matrix <- as.matrix(C)
X_final_matrix <- as.matrix(X_final)
X_star <- as.data.frame(C_matrix %*% X_final_matrix)
ols_model_glssubstitute <- lm(Y_star ~ ., data = X_star)
ols_model_glssubstitute_summary = summary(ols_model_glssubstitute)
print(ols_model_glssubstitute_summary)


##### Performing the Jarque-Bera test on the residuals
res_gls = residuals(ols_model_glssubstitute_summary)
jarque_bera_test <- jarque.bera.test(res_gls)

# Jarque-Bera test results: test statistic and p-value
jb_value <- jarque_bera_test$statistic
jb_p_value <- jarque_bera_test$p.value

cat("Jarque-Bera Test Statistic:", jb_value, "\n")
cat("P-value:", jb_p_value, "\n")


##### Performing the Durbin-Watson test
dw_statistic <- dwtest(ols_model_glssubstitute)
cat("Durbin-Watson statistic:", dw_statistic$statistic, "\n")


##### Performing the Breusch-Pagan test
bp_statistic <- bptest(ols_model_glssubstitute)
cat("Breusch-Pagan statistic:", bp_statistic$statistic, "\n")



##########Back-testing#############
df_bt = read.csv('final_dataset_backtesting.csv')
Y_test <- df_bt$Sea_level
X_test <- df_bt[ c('Sea_CO2', 'Stratification', 'OCH.2000', 'Ice_index', 'Salinity')]
# Back-predict using GLS
# Assuming 'gls_model' is your fitted GLS model
Y_pred_gls <- predict(ols_model_glssubstitute, newdata = X_test)
library(Metrics)
# Calculate the RMSE
rmse_gls <- sqrt(mse(na.omit(Y_test), na.omit(Y_pred_gls)))

# Displaying RMSE and first few actual and predicted values
print(paste("RMSE for GLS:", rmse_gls))
head(data.frame(Y_test, Y_pred_gls))

# Back-predict using OLS
# Assuming 'ols_model_final' is your fitted OLS model
Y_pred_ols <- predict(ols_model_final, newdata = X_test)

# Calculate the RMSE
rmse_ols <- sqrt(mse(na.omit(Y_test), na.omit(Y_pred_ols)))

# Displaying RMSE and first few actual and predicted values
print(paste("RMSE for OLS:", rmse_ols))
head(data.frame(Y_test, Y_pred_ols))